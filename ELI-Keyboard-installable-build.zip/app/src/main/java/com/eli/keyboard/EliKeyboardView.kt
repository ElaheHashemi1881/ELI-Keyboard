package com.eli.keyboard

import android.content.Context
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.view.MotionEvent
import android.view.View
import kotlin.math.max

class EliKeyboardView(
    context: Context,
    private val onAction: (KeyAction) -> Unit
) : View(context) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var isEnglish = false
    private var shift = false
    private var pressedIndex = -1
    private var pressStarted = 0L

    private val faRows = listOf(
        "ض ص ث ق ف غ ع ه خ ح ج چ".split(" "),
        "ش س ی ب ل ا ت ن م ک گ".split(" "),
        "ظ ط ز ر ذ د پ و ژ".split(" ")
    )

    private val enRows = listOf(
        "Q W E R T Y U I O P".split(" "),
        "A S D F G H J K L".split(" "),
        "Z X C V B N M".split(" ")
    )

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        canvas.drawColor(Color.rgb(231, 248, 255))

        val w = width.toFloat()
        val h = height.toFloat()
        val rowH = h * 0.19f
        val gap = max(6f, w * 0.012f)
        val top = h * 0.05f

        var index = 0
        val rows = if (isEnglish) enRows else faRows

        rows.forEachIndexed { r, row ->
            val usable = w - gap * (row.size + 1)
            val keyW = usable / row.size
            val y = top + r * (rowH + gap)

            row.forEachIndexed { c, label ->
                val x = gap + c * (keyW + gap)
                drawGlassKey(canvas, x, y, keyW, rowH, label, index == pressedIndex)
                index++
            }
        }

        val bottomY = top + 3 * (rowH + gap)
        val small = w * 0.16f
        drawGlassKey(canvas, gap, bottomY, small, rowH, "🌐", pressedIndex == index++)
        drawGlassKey(canvas, gap * 2 + small, bottomY, w * 0.46f, rowH, if (isEnglish) "English" else "فارسی", pressedIndex == index++)
        drawGlassKey(canvas, w - gap - small, bottomY, small, rowH, "⌫", pressedIndex == index++)
    }

    private fun drawGlassKey(
        canvas: Canvas,
        x: Float,
        y: Float,
        width: Float,
        height: Float,
        label: String,
        pressed: Boolean
    ) {
        val scale = if (pressed) 0.965f else 1f
        val cx = x + width / 2
        val cy = y + height / 2
        val rw = width * scale
        val rh = height * scale

        val rect = RectF(cx - rw / 2, cy - rh / 2, cx + rw / 2, cy + rh / 2)

        paint.shader = LinearGradient(
            rect.left, rect.top, rect.right, rect.bottom,
            intArrayOf(Color.argb(205, 250, 253, 255), Color.argb(150, 197, 220, 255)),
            null,
            Shader.TileMode.CLAMP
        )
        paint.style = Paint.Style.FILL
        canvas.drawRoundRect(rect, 22f, 22f, paint)

        paint.shader = null
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = if (pressed) 3.2f else 1.8f
        paint.color = if (pressed) Color.rgb(174, 137, 255) else Color.argb(190, 255, 255, 255)
        canvas.drawRoundRect(rect, 22f, 22f, paint)

        paint.style = Paint.Style.FILL
        paint.textAlign = Paint.Align.CENTER
        paint.typeface = Typeface.create("sans", Typeface.NORMAL)
        paint.textSize = if (label.length > 2) 22f else 25f
        paint.setShadowLayer(if (pressed) 12f else 5f, 0f, 1f, Color.rgb(132, 120, 220))
        paint.color = Color.rgb(250, 253, 255)
        canvas.drawText(label, cx, cy - (paint.ascent() + paint.descent()) / 2, paint)
        paint.clearShadowLayer()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_DOWN || event.action == MotionEvent.ACTION_MOVE) {
            val newIndex = hitTest(event.x, event.y)
            if (newIndex != pressedIndex) {
                pressedIndex = newIndex
                pressStarted = System.currentTimeMillis()
                invalidate()
            }
            return true
        }

        if (event.action == MotionEvent.ACTION_UP) {
            val idx = hitTest(event.x, event.y)
            if (idx >= 0) performKey(idx)
            pressedIndex = -1
            invalidate()
            return true
        }
        return true
    }

    private fun hitTest(x: Float, y: Float): Int {
        val w = width.toFloat()
        val h = height.toFloat()
        val rowH = h * 0.19f
        val gap = max(6f, w * 0.012f)
        val top = h * 0.05f
        val rows = if (isEnglish) enRows else faRows

        var index = 0
        rows.forEachIndexed { r, row ->
            val usable = w - gap * (row.size + 1)
            val keyW = usable / row.size
            val yy = top + r * (rowH + gap)
            row.forEachIndexed { c, _ ->
                val xx = gap + c * (keyW + gap)
                if (x in xx..(xx + keyW) && y in yy..(yy + rowH)) return index
                index++
            }
        }

        val bottomY = top + 3 * (rowH + gap)
        val small = w * 0.16f
        if (y in bottomY..(bottomY + rowH)) {
            if (x in gap..(gap + small)) return index
            index++
            if (x in (gap * 2 + small)..(gap * 2 + small + w * 0.46f)) return index
            index++
            if (x >= w - gap - small) return index
        }
        return -1
    }

    private fun performKey(index: Int) {
        val rows = if (isEnglish) enRows else faRows
        val totalLetters = rows.sumOf { it.size }

        if (index < totalLetters) {
            var n = index
            for (row in rows) {
                if (n < row.size) {
                    var value = row[n]
                    if (isEnglish && shift) value = value.uppercase()
                    onAction(KeyAction.Text(value))
                    if (isEnglish && shift) shift = false
                    return
                }
                n -= row.size
            }
        }

        when (index - totalLetters) {
            0 -> onAction(KeyAction.SwitchLanguage)
            1 -> onAction(KeyAction.Space)
            2 -> onAction(KeyAction.Delete)
        }
    }

    fun toggleLanguage() {
        isEnglish = !isEnglish
        invalidate()
    }

    fun toggleShift() {
        shift = !shift
        invalidate()
    }
}
