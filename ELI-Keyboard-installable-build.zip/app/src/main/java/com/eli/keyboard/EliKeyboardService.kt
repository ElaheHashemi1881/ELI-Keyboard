package com.eli.keyboard

import android.inputmethodservice.InputMethodService
import android.view.View
import android.view.inputmethod.InputConnection

class EliKeyboardService : InputMethodService() {

    private lateinit var keyboardView: EliKeyboardView

    override fun onCreateInputView(): View {
        keyboardView = EliKeyboardView(this) { action ->
            handleAction(action)
        }
        return keyboardView
    }

    private fun handleAction(action: KeyAction) {
        val ic: InputConnection = currentInputConnection ?: return

        when (action) {
            is KeyAction.Text -> ic.commitText(action.value, 1)
            KeyAction.Space -> ic.commitText(" ", 1)
            KeyAction.Delete -> ic.deleteSurroundingText(1, 0)
            KeyAction.Enter -> ic.sendKeyEvent(
                android.view.KeyEvent(
                    android.view.KeyEvent.ACTION_DOWN,
                    android.view.KeyEvent.KEYCODE_ENTER
                )
            )
            KeyAction.SwitchLanguage -> keyboardView.toggleLanguage()
            KeyAction.Shift -> keyboardView.toggleShift()
        }
    }
}

sealed interface KeyAction {
    data class Text(val value: String) : KeyAction
    data object Space : KeyAction
    data object Delete : KeyAction
    data object Enter : KeyAction
    data object SwitchLanguage : KeyAction
    data object Shift : KeyAction
}
