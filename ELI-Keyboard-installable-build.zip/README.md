# ELI Keyboard | کیبورد الی

نسخه‌ی اولیه‌ی پروژه‌ی کیبورد الی برای Android.

## وضعیت این نسخه
- Android InputMethodService واقعی
- چیدمان فارسی پایه
- کلیدهای شیشه‌ای آبی/بنفش
- بازخورد لمس نرم
- کلید فاصله، حذف، Enter و تغییر زبان
- انگلیسی پایه
- لوگوی ELI
- بدون صدای کلید

## باز کردن پروژه
پروژه را در Android Studio باز کنید و Gradle Sync را انجام دهید.

این نسخه هنوز APK نهایی نیست و قابلیت‌های پیشرفته مثل Swipe Typing، پیش‌بینی واژه و Emoji Intelligence در مراحل بعدی اضافه می‌شوند.

## ساخت APK خارج از این محیط

این پروژه یک workflow آماده‌ی GitHub Actions هم دارد: `.github/workflows/build-apk.yml`.
پس از قرار دادن پروژه در یک repository و اجرای workflow با نام **Build ELI Keyboard APK**، فایل APK به‌عنوان Artifact منتشر می‌شود.

## توجه
در محیط فعلی ChatGPT، Android SDK و Gradle قابل نصب/دریافت نیستند و دسترسی شبکه برای اجرای build وجود ندارد؛ بنابراین APK نهایی از داخل همین محیط قابل تولید و اعتبارسنجی نیست.


## سریع‌ترین راه گرفتن APK
1. این پوشه را در یک repository جدید GitHub آپلود کنید.
2. در GitHub به Actions بروید.
3. workflow با نام `Build ELI Keyboard APK` را اجرا کنید.
4. پس از موفقیت، از بخش Artifacts فایل `ELI-Keyboard-debug-apk` را دانلود کنید.
5. فایل APK را روی گوشی Android نصب کنید.
6. از Settings > System > Languages & input > On-screen keyboard، ELI Keyboard را فعال و انتخاب کنید.

برای build محلی، Android Studio نسخه سازگار با AGP 9.4 و JDK 17 لازم است.
